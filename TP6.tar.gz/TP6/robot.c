#include "robot.h"

/* initialiser le robot r en position (x,y) et orientation o */
void init_robot(Robot *r, int x, int y, Orientation o)
{
    r->x = x;
    r->y = y;
    r->o = o;
}

/* faire avancer le robot d'une case */
void avancer(Robot *r)
{
    switch(orient(r))
    {
        case Nord:
            r->y--;
            break;
        case Sud:
            r->y++;
            break;
        case Ouest:
            r->x--;
            break;
        case Est:
            r->x++;
            break;
    }
}

/* faire tourner le robot à gauche */
void tourner_a_gauche(Robot *r)
{
    switch(orient(r))
    {
        case Nord:
            r->o = Ouest;
            break;
        case Sud:
            r->o = Est;
            break;
        case Ouest:
            r->o = Sud;
            break;
        case Est:
            r->o = Nord;
            break;
    }
}

/* faire tourner le robot à droite */
void tourner_a_droite(Robot *r)
{
    tourner_a_gauche(r);
    tourner_a_gauche(r);
    tourner_a_gauche(r);
}

/* recupere la position de la case du robot */
void position(Robot *r, int *x, int *y)
{
    *x = r->x;
    *y = r->y;
}

/* recupere la position en abscisse de la case du robot */
int abscisse(Robot *r)
{
    return r->x;
}

/* recupere la position en ordonnee de la case du robot */
int ordonnee(Robot *r)
{
    return r->y;
}

/* recupere l'orientation du robot */
Orientation orient(Robot *r)
{
    return r->o;
}

/* recupere la position de la case devant le robot */
void position_devant(Robot *r, int *x, int *y)
{
    switch(orient(r))
    {
        case Nord:
            *x = abscisse(r);
            *y = ordonnee(r) - 1;
            break;
        case Sud:
            *x = abscisse(r);
            *y = ordonnee(r) + 1;
            break;
        case Ouest:
            *x = abscisse(r) - 1;
            *y = ordonnee(r);
            break;
        case Est:
            *x = abscisse(r) + 1;
            *y = ordonnee(r);
            break;
    }
}