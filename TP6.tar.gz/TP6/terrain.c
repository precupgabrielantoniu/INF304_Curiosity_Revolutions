
#include "terrain.h"
#include "robot.h"
#include <stdio.h>
#include <string.h>

void afficher_erreur(erreur_terrain e)
{
  switch(e)
  {
    case OK:
      printf("Ca marche\n");
      break;
    case ERREUR_FICHIER:
      printf("Erreur de fichier\n");
      break;
    case ERREUR_VALEUR:
      printf("Valeur invalide\n");
      break;
    case ERREUR_LONGUEUR_LIGNE:
      printf("Erreur de longueur de ligne\n");
      break;
    case ERREUR_CARACTERE:
      printf("Caractere inconnue dans la carte\n");
      break;
    case ERREUR_ROBOT_MANQUANT:
      printf("Manque de position initiale\n");
      break;
    case ERREUR_NOMBRE_LIGNES:
      printf("Pas le bon nombre de lignes\n");
      break;
  }
}

erreur_terrain lire_terrain(FILE *f, Terrain *t, int *x, int *y) {
  int l, h;   // Dimensions du terrain
  int rx = -1, ry = -1; // Coordonnées initiales du robot

  if (f == NULL) {
    return ERREUR_FICHIER;
  }

  // Lecture de la largeur
  fscanf(f, "%d", &l);
  fscanf(f, "\n");
  if(l > DIM_MAX) return ERREUR_VALEUR;
  t->largeur = l;

  // Lecture de la hauteur
  fscanf(f, "%d", &h);
  fscanf(f, "\n");
  if(h > DIM_MAX) return ERREUR_VALEUR;
  t->hauteur = h;

  // Lecture du terrain
  for(int i = 0; i < h; i++)
  {
    char c;
    for(int j = 0; j < l; j++)
    {
      Case cs;
      if(!feof(f))
      {
        fscanf(f, "%c", &c);
      }
      else if(i == h - 1)
      {
        if (j == 0) return ERREUR_NOMBRE_LIGNES;
        else return ERREUR_LONGUEUR_LIGNE;
      }
      else return ERREUR_NOMBRE_LIGNES;
      if(c == '\n' && j != 0) return ERREUR_LONGUEUR_LIGNE;
      else if(c == '\n') return ERREUR_NOMBRE_LIGNES;
      switch(c)
      {
        case '.':
          cs = LIBRE;
          break;
        case '#':
          cs = ROCHER;
          break;
        case '~':
          cs = EAU;
          break;
        case 'C':
          cs = LIBRE;
          rx = j;
          ry = i;
          break;
        default:
          return ERREUR_CARACTERE;
      }
      t->tab[j][i] = cs;
    }
    if(!feof(f))
    {
      fscanf(f, "%c", &c);
    }
    else if(i != h - 1) return ERREUR_NOMBRE_LIGNES;
    if(c != '\n') return ERREUR_LONGUEUR_LIGNE;
  }
  if(!feof(f))
  {
    char c;
    fscanf(f, "%c", &c);
    if (c != ' ' && c != '\n' && c != '\0') return ERREUR_NOMBRE_LIGNES;
  }

  // Initialisation de la position du robot
  if(rx == -1 || ry == -1) return ERREUR_ROBOT_MANQUANT;
  *x = rx;
  *y = ry;

  return OK;
}

int largeur(Terrain *t)
{
  return t->largeur;
}

int hauteur(Terrain *t)
{
  return t->hauteur;
}

int est_case_libre(Terrain *t, int x, int y)
{
  return ((0 <= x && x < largeur(t)) && (0 <= y && y < hauteur(t)) && t->tab[x][y] == LIBRE);
}

void afficher_terrain(Terrain *t)
{
  int l = largeur(t), h = hauteur(t);
  for(int i = 0; i < h; i++)
  {
    for(int j = 0; j < l; j++)
    {
      Case cs = t->tab[j][i];
      char c;
      switch(cs)
      {
        case LIBRE:
          c = '.';
          break;
        case EAU:
          c = '~';
          break;
        case ROCHER:
          c = '#';
          break;
      }
      printf("%c", c);
    }
    printf("\n");
  }
}

void ecrire_terrain(FILE *f, Terrain *t, int x, int y)
{
  int l = largeur(t), h = hauteur(t);
  fprintf(f, "%d\n", l);
  fprintf(f, "%d\n", h);
  for(int i = 0; i < h; i++)
  {
    for(int j = 0; j < l; j++)
    {
      Case cs = t->tab[j][i];
      char c;
      switch(cs)
      {
        case LIBRE:
          if(j == x && i == y) c = 'C';
          else c = '.';
          break;
        case EAU:
          c = '~';
          break;
        case ROCHER:
          c = '#';
          break;
      }
      fprintf(f, "%c", c);
    }
    fprintf(f, "\n");
  }
}